package com.example.groceryapp;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;

import androidx.activity.ComponentActivity;

public class DetailsActivity extends ComponentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        DashboardActivity.GroceryEntity e =
                (DashboardActivity.GroceryEntity) getIntent().getSerializableExtra("entity");

        TextView tvTitle = findViewById(R.id.tvTitle);
        TextView tvSubtitle = findViewById(R.id.tvSubtitle);
        TextView tvDesc = findViewById(R.id.tvDesc);

        if (e == null) {
            // Defensive fallback
            setTitle("Details");
            tvTitle.setText("Unknown item");
            tvSubtitle.setText("");
            tvDesc.setText("No details available.");
            return;
        }

        // --- Build robust strings so UI is never blank ---
        String title = firstNonEmpty(
                e.property1,
                // if property1 missing, try using the first sentence of description
                firstSentence(e.description),
                "Item details"
        );

        String subtitle = firstNonEmpty(
                e.property2,
                // if property2 missing, show a compact preview
                shortPreview(e.description),
                ""
        );

        String desc = firstNonEmpty(e.description, "No additional description.");

        // Set text
        tvTitle.setText(title);
        tvSubtitle.setText(subtitle);
        tvDesc.setText(desc);

        // Set activity bar title too (nice for navigation)
        setTitle(title);

        // Accessibility
        tvTitle.setContentDescription("Title: " + title);
        if (!TextUtils.isEmpty(subtitle)) {
            tvSubtitle.setContentDescription("Summary: " + subtitle);
        }
        tvDesc.setContentDescription("Description: " + desc);
    }

    private static String firstNonEmpty(String... vals) {
        for (String v : vals) {
            if (v != null) {
                String t = v.trim();
                if (!t.isEmpty()) return t;
            }
        }
        return "";
    }

    private static String firstSentence(String s) {
        if (s == null) return "";
        String t = s.trim();
        if (t.isEmpty()) return "";
        int dot = t.indexOf('.');
        return (dot > 0 && dot < t.length() - 1) ? t.substring(0, dot + 1) : t;
    }

    private static String shortPreview(String s) {
        if (s == null) return "";
        String t = s.trim();
        if (t.length() <= 60) return t;
        return t.substring(0, 57) + "...";
    }
}
