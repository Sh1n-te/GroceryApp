package com.example.groceryapp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.ComponentActivity;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Path;

public class DashboardActivity extends ComponentActivity {

    // --- Inline models + API ---
    static class GroceryEntity implements Serializable {
        @SerializedName(value = "property1", alternate = {"name", "title", "item", "product"})
        String property1;

        @SerializedName(value = "property2", alternate = {"value", "subtitle", "quantity", "price", "category"})
        String property2;

        @SerializedName("description")
        String description;
    }
    static class DashboardResponse { List<GroceryEntity> entities; int entityTotal; }

    interface Api {
        @GET("dashboard/{keypass}")
        Call<DashboardResponse> dash(@Path("keypass") String keypass);
    }

    private static final String BASE_URL = "https://nit3213api.onrender.com/";

    private Api api;
    private ProgressBar progress;
    private TextView tvError;
    private GroceryAdapter adapter;
    private String keypass; // keep for retries

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        setTitle("Dashboard");

        keypass = getIntent().getStringExtra("keypass");

        RecyclerView rv = findViewById(R.id.rv);
        progress = findViewById(R.id.progress);
        tvError = findViewById(R.id.tvError);

        // Wire the header Logout button (present in your updated XML)
        View btnLogout = findViewById(R.id.btnLogout);
        if (btnLogout != null) {
            btnLogout.setOnClickListener(v -> logout());
        }

        adapter = new GroceryAdapter(this::openDetails);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);
        rv.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        // Retrofit with logging + reasonable timeouts
        HttpLoggingInterceptor log = new HttpLoggingInterceptor();
        log.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient ok = new OkHttpClient.Builder()
                .addInterceptor(log)
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .writeTimeout(20, TimeUnit.SECONDS)
                .build();
        api = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(ok)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(Api.class);

        if (keypass == null || keypass.trim().isEmpty()) {
            showError("Missing keypass from login. Please log in again.");
            return;
        }

        // Tap error text to retry
        tvError.setOnClickListener(v -> load(keypass));

        load(keypass);
    }

    private void logout() {
        // Clear back stack and go to Login
        Intent i = new Intent(this, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    private void load(String keypass) {
        setLoading(true);
        tvError.setVisibility(View.GONE);

        api.dash(keypass).enqueue(new Callback<DashboardResponse>() {
            @Override public void onResponse(@NonNull Call<DashboardResponse> call, @NonNull Response<DashboardResponse> resp) {
                if (isFinishing() || isDestroyed()) return;
                setLoading(false);

                if (resp.isSuccessful() && resp.body()!=null) {
                    List<GroceryEntity> list = resp.body().entities;
                    if (list == null || list.isEmpty()) {
                        adapter.submit(new ArrayList<>());
                        showError("No items found.");
                    } else {
                        tvError.setVisibility(View.GONE);
                        adapter.submit(list);
                    }
                } else {
                    showError("Dashboard error (" + resp.code() + ")");
                }
            }

            @Override public void onFailure(@NonNull Call<DashboardResponse> call, @NonNull Throwable t) {
                if (isFinishing() || isDestroyed()) return;
                setLoading(false);
                showError(t.getMessage());
            }
        });
    }

    private void openDetails(GroceryEntity e) {
        Intent i = new Intent(this, DetailsActivity.class);
        i.putExtra("entity", e);
        startActivity(i);
    }

    private void setLoading(boolean b){ progress.setVisibility(b ? View.VISIBLE : View.GONE); }
    private void showError(String msg){
        tvError.setVisibility(View.VISIBLE);
        tvError.setText(msg == null ? "Unknown error" : msg);
    }

    // ------- Minimal adapter (inner class) using simple_list_item_2 -------
    static class GroceryAdapter extends RecyclerView.Adapter<GroceryAdapter.VH> {
        interface Click { void onItem(GroceryEntity e); }
        private final List<GroceryEntity> data = new ArrayList<>();
        private final Click click;

        GroceryAdapter(Click c){
            this.click = c;
            setHasStableIds(true);
        }

        void submit(List<GroceryEntity> items){
            data.clear();
            if (items != null) data.addAll(items);
            notifyDataSetChanged();
        }

        @Override public long getItemId(int position) {
            GroceryEntity e = data.get(position);
            int h = ((e.property1 == null ? "" : e.property1) + "|" + (e.property2 == null ? "" : e.property2)).hashCode();
            return h;
        }

        @NonNull @Override public VH onCreateViewHolder(@NonNull android.view.ViewGroup parent, int viewType) {
            android.view.View v = android.view.LayoutInflater.from(parent.getContext())
                    .inflate(android.R.layout.simple_list_item_2, parent, false);
            return new VH(v);
        }

        @Override public void onBindViewHolder(@NonNull VH h, int pos) {
            GroceryEntity e = data.get(pos);

            String title = (e.property1 != null && !e.property1.trim().isEmpty())
                    ? e.property1.trim()
                    : (e.description != null && !e.description.trim().isEmpty()
                    ? e.description.trim()
                    : "Item " + (pos + 1));

            String subtitle = (e.property2 != null && !e.property2.trim().isEmpty())
                    ? e.property2.trim()
                    : (e.description != null ? shortPreview(e.description) : "");

            h.t1.setText(title);
            h.t2.setText(subtitle);

            // Ensure readable colors on any theme
            h.t1.setTextColor(Color.parseColor("#212121"));
            h.t2.setTextColor(Color.parseColor("#616161"));

            h.itemView.setOnClickListener(v -> click.onItem(e));
        }

        private static String shortPreview(String s) {
            if (s == null) return "";
            s = s.trim();
            return s.length() <= 60 ? s : s.substring(0, 57) + "...";
        }

        @Override public int getItemCount() { return data.size(); }

        static class VH extends RecyclerView.ViewHolder {
            android.widget.TextView t1, t2;
            VH(@NonNull android.view.View itemView) {
                super(itemView);
                t1 = itemView.findViewById(android.R.id.text1);
                t2 = itemView.findViewById(android.R.id.text2);
            }
        }
    }
}
