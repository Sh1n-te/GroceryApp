package com.example.groceryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.activity.ComponentActivity;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.*;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.Path;

public class LoginActivity extends ComponentActivity {

    interface Api {
        @POST("{city}/auth")
        Call<LoginResponse> login(@Path("city") String city, @Body LoginRequest body);
    }
    static class LoginRequest { String username, password; LoginRequest(String u,String p){username=u;password=p;} }
    static class LoginResponse { String keypass; }

    private Api api;
    private ProgressBar progress;
    private TextView tvError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText etU = findViewById(R.id.etUsername);
        EditText etP = findViewById(R.id.etPassword);
        Button btn = findViewById(R.id.btnLogin);
        progress = findViewById(R.id.progress);
        tvError = findViewById(R.id.tvError);

        // Retrofit (inline)
        HttpLoggingInterceptor log = new HttpLoggingInterceptor();
        log.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient ok = new OkHttpClient.Builder().addInterceptor(log).build();
        api = new Retrofit.Builder()
                .baseUrl("https://nit3213api.onrender.com/")
                .client(ok)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(Api.class);

        btn.setOnClickListener(v -> {
            String u = etU.getText().toString().trim();
            String p = etP.getText().toString().trim();
            if (u.isEmpty() || p.isEmpty()) {
                showError("Please enter username and student ID.");
                return;
            }
            doLogin(u, p);
        });
    }

    private void doLogin(String u, String p) {
        setLoading(true);
        tvError.setVisibility(View.GONE);

        api.login("sydney", new LoginRequest(u, p)).enqueue(new Callback<LoginResponse>() {
            @Override public void onResponse(Call<LoginResponse> call, Response<LoginResponse> resp) {
                setLoading(false);
                if (resp.isSuccessful() && resp.body()!=null && resp.body().keypass!=null) {
                    Intent i = new Intent(LoginActivity.this, DashboardActivity.class);
                    i.putExtra("keypass", resp.body().keypass);
                    startActivity(i);
                    finish();
                } else showError("Login failed ("+resp.code()+")");
            }
            @Override public void onFailure(Call<LoginResponse> call, Throwable t) {
                setLoading(false);
                showError(t.getMessage());
            }
        });
    }

    private void setLoading(boolean b){ progress.setVisibility(b?View.VISIBLE:View.GONE); }
    private void showError(String msg){ tvError.setVisibility(View.VISIBLE); tvError.setText(msg==null?"Unknown error":msg); }
}
